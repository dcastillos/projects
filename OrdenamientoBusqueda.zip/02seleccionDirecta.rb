def buscaMenor(k,indMay)
    indice=k
    menor=$arreglo[k]
	for m in k..indMay
	   	if (menor>$arreglo[m])
    		menor =$arreglo[m]
    		indice=m
    	end
    end
   	return indice
end
def seleccionDirecta
	indMayor = $arreglo.size-1
	for i in 0..indMayor
        j=buscaMenor(i,indMayor)
        valor=$arreglo[j]
        $arreglo[j]=$arreglo[i]
        $arreglo[i]=valor
    end
end
def muestraArreglo
    indMayor = $arreglo.size-1
    for i in 0..indMayor
    	puts $arreglo[i]
    end
end
$arreglo=[34,8,64,51,32,21]
muestraArreglo
puts "------"
seleccionDirecta
muestraArreglo