def intercambioDirecto
	indMayor = $arreglo.size-1
	intercambio=true
	while intercambio == true
		intercambio=false
		for i in 0..indMayor-1
			if ($arreglo[i]>$arreglo[i+1])
				valor=$arreglo[i]
				$arreglo[i]=$arreglo[i+1]
				$arreglo[i+1]=valor
				intercambio=true
			end
		end
	end	
end
def muestraArreglo
    indMayor = $arreglo.size-1
    for i in 0..indMayor
    	puts $arreglo[i]
    end
end
$arreglo=[34,8,64,51,32,21]
muestraArreglo
puts "------"
intercambioDirecto
muestraArreglo